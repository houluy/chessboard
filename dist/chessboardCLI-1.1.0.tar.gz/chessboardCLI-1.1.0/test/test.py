from colorline import cprint

cprint('hhh', end='')
print('a')
